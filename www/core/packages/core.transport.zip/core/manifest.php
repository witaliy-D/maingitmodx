<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5b92449df48bb908c12416af9d06ffae',
      'native_key' => 'core',
      'filename' => 'modNamespace/a20b9430d97359b207579bf036595816.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '38577faf1b0d1706c2adf89551f467a9',
      'native_key' => 1,
      'filename' => 'modWorkspace/b380870b21035e5bd7da2cc7b64bde68.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '3bf1e4a2d6d1acfbdc66eb9367314679',
      'native_key' => 1,
      'filename' => 'modTransportProvider/a007c4884b13c40eb6d641d60e6a5812.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'aea2f7d552feae68cf1e4e196fe117ab',
      'native_key' => 'topnav',
      'filename' => 'modMenu/8363dd82370bac4e4a46449c89f60df2.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '099664e233ab1d8315db9d1c0bac1f03',
      'native_key' => 'usernav',
      'filename' => 'modMenu/38c75b57685de1bf52ed28827edb7842.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5e739fb6c6fcb67eb70111b0d0aab1ef',
      'native_key' => 1,
      'filename' => 'modContentType/1e2136fb95fedef3b067d79d7d82851e.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3f74abdcb89e749f65c8303b2a796a4f',
      'native_key' => 2,
      'filename' => 'modContentType/d6fb5a3bb25a33feb9dedf47dfa26e4c.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '34ecab2fc7967c3d9d936f35f4b75fab',
      'native_key' => 3,
      'filename' => 'modContentType/dfc58a074ca2db64ce33e0d73752dd17.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ab12b31547823e4a5466d05637de8ed6',
      'native_key' => 4,
      'filename' => 'modContentType/8745bceff76ee81f8ba79b7825b094ac.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '1ac06cbfcac1bd24dd80d1a90c367370',
      'native_key' => 5,
      'filename' => 'modContentType/d1eae744c638207ed1da004c5bed450f.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '59bd810239b5bdd01dd098f8d75dc7cc',
      'native_key' => 6,
      'filename' => 'modContentType/4eb8ff2e1b7db94b52df91cde7753c34.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3e1f51b833e294183bd7846247bef08e',
      'native_key' => 7,
      'filename' => 'modContentType/cebdd7f76a2b6ed9cae97924d318e6a3.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'cad867713041f12ef1f0ddd8b83e16bc',
      'native_key' => 8,
      'filename' => 'modContentType/7615463910c6753dd824152898a4cd88.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cac727f5520142b03ae8baa86b415b27',
      'native_key' => NULL,
      'filename' => 'modClassMap/c0eaf7695802cfabdabe594aec801ed2.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c3d22a619cb8265e74107ceb64183a5e',
      'native_key' => NULL,
      'filename' => 'modClassMap/380cb48bd63748de9526f9378d9ae58b.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '00a417641b8295b00ec55ee813c0cd69',
      'native_key' => NULL,
      'filename' => 'modClassMap/4fd475012da5b43d0c0987dcf52cec0e.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'dc6fe4cbb63510c4359916dd42c921e6',
      'native_key' => NULL,
      'filename' => 'modClassMap/6bd4942a2908699ce8a7352df619ff0a.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3ecda7afcaefab2d1f7e5adf39eec597',
      'native_key' => NULL,
      'filename' => 'modClassMap/72a725f4a9982b7b02994bfce29a273d.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '705a61bdea56a811890c64e82b10ecec',
      'native_key' => NULL,
      'filename' => 'modClassMap/19d1ae4bedef266a0f3053afc8683591.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f084beb903e166d9297bc3a246b73e15',
      'native_key' => NULL,
      'filename' => 'modClassMap/451cbc9eaa3afdcde651203de33a4528.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '3594e9d35f115d507ee1583a51232cfb',
      'native_key' => NULL,
      'filename' => 'modClassMap/3dafccb23404b8c0368c0f32aecbbbb9.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '00294af7c49a27699cba11438608faa8',
      'native_key' => NULL,
      'filename' => 'modClassMap/7f9766e63ec16c72adc5eb868f7c6b82.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19b3b2e605088805034f9e26a2c27539',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/fdb0755139cab0c6b5fc8bcad9218506.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c1b6c0e7b1404936165a137d051ce5b',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/767d72dcc606d710be9e924c21aa4f4a.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '022b36ca8a8feddd7c406a0d3e50d51b',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/23c866b7e8a3823d72a1ad16472d5fca.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba6dc58b520daf891def181caba567bb',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/6f8e7f90cafa044e1b336447c962e00f.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed0b7b3ffbf880d9972300d24d9af240',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/7337a474416912d748cc0bbbb002e24b.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '607ab1706ceb03419b88196c00434187',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/14122d9c93a5fc2f168e31ad342b8574.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c73fb1ea385d0a6d24216b1315d1c915',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/913237922d2fe6ba4bfa8d131722fb08.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e716857f021e8057470d4dfe5429448',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/79c5bcea3feef01c13fd6edeaf458757.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '892a481adb3b5998ed63d08d192975ba',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/ecaa237e51da929e864dbcdcc575b89b.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f0bab8fd2da7ce2cd2e89b760cad377',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/e485404b5e0474df6e08bcce395764a9.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2607fcd23a84205688ad6dad77e2af9a',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/da72e1275b8309fc9234217540745b1d.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5b624e43b128a04f2cf5d84104804bf',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/3426d72d151e3b22e46d2de3ad228f1e.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b79130a503ac0a3e2b2692470d222a4a',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/2b33e39ce8699747819d0b98818d1eef.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de3145ee7ee0dd5f6ca806d941dd7298',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/22a8dcdc5bb28539cfa1bbe0ac4cabe6.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb4d36803c5128b9cde7e6c0901fd87f',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/43d5a6fdf34b7330e514b1bcf6cd3857.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba869cbd6767603cdb03e38abb600f8c',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/459d329b9df1ed89297d84a73787c263.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1bbad884cd4d4add7071bc05ade69f1',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/a0ac67496a986cd833910e145bfbd843.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '852dc6bc6ee8a67e193016ebf2ed6a51',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/29274e3b53428305d3f3218af0fc0601.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc3afb526be4992c434f0fe508637d63',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/24ac2f6e41b43902a0bb02e8fe3434c3.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a8a1c7bccc9e52a3ae893e870e308f9',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/797e8f6cd19338452968efec62d1379d.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f696fdb9d52e243f94ba3bfdb479cf5',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/f1a8672894541992c5e2131c10e41017.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a003ef6df430dbc742015e7d54f4713b',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/31850ee1255e0f4d3748bf0956d303b8.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcc5355d3f41c2b156b2c8b8e9cf5b6b',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/f7ca2f286703cd9689bcfdfbbb5e8ea5.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b25b447fa71723347949edd8e98cb7da',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/8dcb6d87ec9e9caf582c935b36f8a8f0.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '731e12cb2abfeaf8a216c17c0a3e6870',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/df9e7318b42747bf0c95f4823b6f08cb.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '956c31dd7447ca1958558039c909de18',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/02d84622edaaab95a600abca3f1581e8.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '910c0b30dfa39cc93a2461ae1d913242',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/d95643a4aff711537683615b1b83ec59.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dab9feb5faecc26509a2ae0bb0bc380d',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/0c6aaa54d559543b2aa4063afe1e3f6d.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43dd9549610b5c01f59203b0dc8a0aec',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/419f8f277de3c95910f185e1406c3801.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ea770d409a843ba732743cf51118b59',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/ae13db6be11bd4512be99e5d7999dbf1.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76deb23e5cc4e188ee931ebed238de67',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/7d6800bca1aae4bb4499f55d3bae1868.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc57563bcc92464d46028fe0cd2182bc',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/12a3cda3bd1ad2165eaa9ae38a3cc1b1.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3ee36d4c8f9590eebea6ad7a26d845d',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/8fb5adc9e7f29b328ba7d7a82af37cd8.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ae4ddec935b54f09997f6d9c3c9ad27',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/49d59c404a9d01bd84da93d686c4e906.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8540ec801691a8f613dc3d2836487412',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/d6987071c99f48b42ebd0aefeb275e68.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f6a6fcac783fbfe59eb557836097d83f',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/726ff0de6d303c027223048a7242bbe3.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a14f39c9a9cd7659afc4f3a0b220bbf0',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/36d5eb3c4e5b97b364f1730df6a4d97b.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af69f6a96b1538b468cfc735c47d98b4',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/b31c634a31d545721cd2a9644aa3acd6.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3948867ef6265be54c1d3315218bdf69',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/4e072f3f75f911fd73bffb94ebf194f0.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03014ef0dc5fd8a763bfd765ac0b5823',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/596b0c6af3fd64ac9704aac88eaa6a27.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '815696df9e6f686458144ea2b8b64b45',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/d88f8b68f4d724d601541f14a4ff463a.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9579d5b4a961bf0c115bd1a4147b9662',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/35226f16a394e6a41e2d0c93f8cefcab.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcc120698c7b49da2e61c6630d6f51f3',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/59854a3113a0a4611d80722692ed6f76.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87c34e195ca3c12b93c4cbcb6f8eebfb',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/f3bec4bdc865df12a36b195158118622.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '322c5efb75893a34ad18a7fbb11fdc44',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/f357d99f3bff6a87f48dc3c116d6f3e3.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1b3282a3fe429cca7f3e602f89c4b92',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/dfa75b655b8fefa5eb3dd5a0fcc26b51.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f63f49d359a0d080db00769b00793fd',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/dad0e4567d78fdb6ed2401c3526795d8.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2050348e2a3d62b37e910b45fa5027a',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/6232cb8bfec605faae04a0f7dc8af52c.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1391373d7b5b6b77f3e032b7d996fce9',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/45ed65a2d686b6236e6a817088c5be71.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c497330c162aa939e0bbeb94fee9abc',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/1a750763557f8c3719297af0690ad0cf.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a689cbfac3a00843d9f3cecdadf735ee',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/bc1a495384adbb84386c196ef7fd93df.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '01c37334728c461bfdcb1651667b3d80',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/0e8d42ae1bd1f3dfdd02af4bf8516adb.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6804f703f114461e52bfc88dc950e2f8',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/8afd4ebd956b188ac5690749a3869cf9.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b33d208ddfc1c243733b7e033bb03c73',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/fb889602f51ccb5dacdb0414d7c21760.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8044b4ea4b6db19c13fec2479ad90cf6',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/229d7cb6fd8c623022367c91ea504466.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d7c405d5fc980dd8aa1d906ad0a7db8',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/39544990e2850da70299903a7ad675c6.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7c96aad7f3f6a605d783bf6cd5a9631',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/f7b646ffd3d2ce5336c9b45bc7094fb8.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33d7eeb17356002edd3265f7061e81ae',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/fc4c711d3026b67263d717826414ef2f.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '06a65ce82eacd4ea4c412a23eb30e600',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/096c02ed19bc68a23592adf462db7486.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cf3f1756688d3d5eef82d46e6587614',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/8746b8315df5c9c39b35e764a8e4929d.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '443f3be412911245d1407b3429adb3e4',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/4ea0e5f15dfe924098381ec33a9ee262.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a13c4450aa5af0101eb6cdaf62bbeb45',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/b4e11bd5dcf4b82f6a2e271f13f71d06.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05ead2b40066512aa455132aa7f06d00',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/ffec7d0aa5a1fee1ee1a85618beea24e.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '303fcf99fd43ca6d8ce6131f03f3a9f7',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/c743bc17bd187f82b4198c83c2ad8a25.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '50230b0b7dffef2f1a100e5040516d52',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/ea7188e31398abcf8178f53b3b85b709.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1d06337f649174a8cf39343e9cd9521',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/14fe05fc83edc5306fd1e5716140a7ad.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3adca4b7a41f6da804383b6b6bbb378',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/a409ac51de595ba637fe9aa3611dc729.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '811f0c37e317323c224991df3077766b',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/e11e031b2d110a8127c62d8204319401.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e696741548b995fad1a7d01be29a696d',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/e1062269680f6ecddaaf543228c30666.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0249118e857f96ba7d6d4def9f62eaf4',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/f3b9bc377c4c5f8cdc82401416f86dc6.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0cedd9d72a1feac4f98d54e33a6a26f2',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/e035729eb11bd7d1dda832354fbce078.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '44c9a0ddc652354df5593b67e00c1fc7',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/e9b0cbfc040908a547b540dedf508bae.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '75dfc91306fb39ad8fd3d3b438332a63',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/91a2d184a0e978e445a07eebba767f14.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0fe438cab66e5676c70b2dffd9f3a348',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/5ec8a7901f2c30360d8d1d8823f7f7b2.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6383fcab03468a156e4e5351c1bc9365',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/3954e1bdf4a956af6443e705ed2bd001.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5758fe410db9f675ef0e304df57cf6fe',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/efc51f5d1adf7e3889076a82d14ddef9.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9a3d741460da5fe3f0d9d433b6641da',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/8299a5da1300d5bb8ad6d13e95da5888.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7e5c216b49a850dda0fdb203c8cbc8b0',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/833fc871c655a9bbc4b64c07dda264b4.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d84ea68c5839fa03f38024434eb471d',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/b2eda240f8a406fa99fba0c8b95180c4.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84f747f13aea9c5f856e776f9a8edb7c',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/b25ec1925d566126ca75f95e052b993a.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '881a45b56ee6f2957b837876b4eeab97',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/386447d64a7719fc9399a349dc43b6b4.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43b132b1224dacd1a1c80a0d768e4403',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/b51d0c8ce337d0d9da0310420103e190.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ec1ce8621eee2bcb9a0ae400034ee6a',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/ef6a81d04780858cf5d1e2ce48261ab7.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a1ef2849a3fb88fa0d6f3bdfc5bb17c',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/1f5bee874ee2585a36d6f436eac3a63d.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe0410e7b4ceb7518d29c1e02f14c047',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/266eae893930cad301d0089e7e41f84b.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dca5b9f2704bf102a3988483412d4e4b',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/aa98bd613015f49d7504f8b15444c5d4.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f90e4d7739f08053fc924dff11a9667c',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/c084cbceb0ee09eb45a511a9e9c717be.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45f10ad35a4326fb8eb726db02ac22f8',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/0ec7e3c4d39c5cbd5778df24c3d07b46.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '18e46c3d86aaae4e79d0775b06a1fbfe',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/bf2b1ba9bf869cd66f676c39d39c7e86.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eee51cd916d9e377b87a12ec1614dd9e',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/649af7d6253398d55177eb34e1003d8b.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec580b18f4b9ba679a2ff0e44bd7fb94',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/161cc9666bccae102123d66edd7d6cbd.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '996ce89cc2afdadfea5f2a3f4b2bc333',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/85340b53ee36f2ed0a77d1f8f8e1a0e8.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2e1cfcae0cd3a6c5a40153f5ddf7687',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/50525b2c3b3c9942b79f523950ed098b.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e21fca0814a5fb5b5f31de2782b2ab7b',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/0d83ae43ff085c3e62b86feb8806eeeb.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8acfc84d01c6204d93d870973e9dbce6',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/b94ec2189e2adfd270c6411e0b7affef.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19c1bd65da0f6df0aa54b36ad39ff1ae',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/55db961ff858d15b543d370641cd0d41.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f3c2c121cc4423a6d5db3df4f92fc74',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/610227d7c8b0f0834a08fd1456f91da6.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c31384ce49517cff488f602440c2b17f',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/1c94dc9d31ed5da2de829160f3660acc.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a4a98065cc3dfd21ce669a4c6c12bae',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/5e348364e77257dfd5f0c32140db8741.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46553d3c205685760569b5c4ececbf43',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/989e23baedb143803f621fe126ff6ed9.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62204509e31ebcba7360dacef669e02a',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/b75d028358f31dd47a73713ef5b4801d.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eac2bd2c6e5913da6452c1afbe0eba54',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/f0e9c8d6436471d62b32fa851fe89c03.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5dd469bd1ea788eaf8604003ca9568e1',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/a878c30c4e069578f29edc464e702718.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79077a4fb7ee5ee1c683709b66c141a5',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/bf6d5cc1f3c004e1355d6801170bd181.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c406a0ddf3d3c00c9c31528e76117105',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/638787098e97fb4a3c87c640a5191a83.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65fa89c85934b0763f1828dcb686532c',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/0a20420fa1c6f5a76c6b877c85f83a03.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6f472a47d830ab016e7f2a9410cedd8',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/99b4a0360a3048a3cf71e8e72541435d.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd3f7c8de7f687bb9de563f59f4fa2f4',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/35e1fd3327e28c00198ffdcd56669e5b.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '14e39e87e9bc9974f10a480bc82464a3',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/d5c07cd8e7ef227473e2c73171b33559.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a98ef0248b769cdc6c9e626fef4d68ab',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/42b0677cd8916522e94badc8efa96fe0.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ce85bebc77f04f26700f75f08041ad9',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/9ca161847744781633861cc2a0b45a91.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6d58ed1985603501ae7c0bfa3733981',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/e480231481acea637ed53b724fc8248d.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c1f0fdcba463acafd4ccbbcfe81d26c',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/fd517cb4417e991e4bec7337ac502ed4.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d63a2e51784858b88abb6b3f3b36bb8',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/38e9fe5bf07d708750ee78ed22fa625a.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a49f42f43a8f3604884761c51ef4d240',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/3d73286c8bbf8871fdfae9c26b635499.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20c4b66ff10773c33310a2fc6121695d',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/0925b602966a280a4c8ac64d23213f67.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c301d4be927da0feef75d7aeb1b6fba',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/01781bd316477f09fb399422ed998255.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9126f174e7d1d47106ab181f7e11121',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/20728495e8b7b6e9d5357f14d0c954d0.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1219ea097f35684fec9566e229c2388',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/b08b188d6652a87f7fe5622605c162dc.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df2cb2c5bdf015bf1c8383fb1b87e7db',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/5b35085891b716c98825a5b38d04f01c.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f98287652d9157613b7ed843bc61faf',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/4247ede0f4c82ca371ac915b5371f42f.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9106c1847f40f78d9b647488893acdd8',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/bc73ea1d420b68edd73e77481cbf18ea.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b838bb08db3bf16cafbb0333ce57dae8',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/e94da2a83dc5a0068b609d3af86577cc.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b10f52f3d3cca79f008b27bb577267b',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/2e665adf5754c2376f6011c591f12484.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5712e2c57cac75fd3ad1b3198e2a9574',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/0ae723411396e357863ba910afe4fbe0.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8acc0bf7f055e046ce8d3b17535285ba',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/8359fe2f64668b960e586a0a221819e4.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dace7d3422db737e4ac1dd856243f85d',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/8712dda543a0ba3f299bee294c6faf57.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2c79b75823c9e4747ffac9d41cbc3c3',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/c65e22bf0cfb146795bff530dff625f6.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49b7d553d585bc5e8311230b9986a761',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/1236b1ef1bb372cd32e4661febef9a90.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4aa2dd301a07791af5a5ab3229d07dce',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/00d0744b436c2f346b315012d6d938f9.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '158e396d44fc9709753af90bf6c1bf36',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/727df657b76978eae92ed3a0b5732a96.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1c6392caf9354a10c7fb759afb5ffbe',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/e2989d313f2693c23ea3177ad6999f89.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6901289cb8bf47c2f50d5c2dbe8efbcf',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/1512cffa202e836c41121f3900863765.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9240646631e0f4869783336709a6edaf',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/4c92395afc44c2ba215e384039df3b70.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a659ee0ebbda39c155badaba703613df',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/9a2d1cdf04ada6eb5aafa1f106a8d47d.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f1e4518a04b0388c1db56ef09958412',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/203d31d191425a14a28dff0483737470.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b265f64102400c0c6b7897c1a3928f0',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/4b0938ef2cbbd101d0bc3b95b05e01a8.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab7a5a0abb754987335d7021c853b216',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/18f5ec7856ad980350436ba20ea818d8.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b3b5c88b09d19d30333861e168c90d7',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/2aa0db4261fe843eb0fbf842aaebaf69.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e558839ac47e0b4e76e6f800153e934',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/590fe8f8c7e353a12bddbc634b67157c.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3157efd381b8eac990ad7f0664ad2a3d',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/bc35d0b8344e2ddf4910467c4288098d.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4bbe7f1ed16b8a6a5595ecedf4df5c7c',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/099c7a4560d1a1bd51308d023f58136e.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f9abe64eb84f0cf4a1c9b8bed52976c',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/4ea30ea8f699d8d1e4c3ff3476f50654.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d813506e6c545e3599feb04e74e9c95',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/f422b46b7f4795a744daa40e6d35bc32.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e17b6c35de6fe0a95ef79e5182e9aa3d',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/2df498142d326b80fe3ade4b601f5b06.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ded090378d7440adaa53fe215ea26db',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/3445d03441e3c21a5883f61b89ebbe19.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c10e28bb705a2bdc610ff2cd788590c5',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/c53f0a1827c4fcece4d661b089dfd12a.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8dd2dc3251b9685343e9e7dd62a2a608',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/86a17c0a96a0eb303a42954a3e0765a8.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '517fa3a0dc7d5cc94fd18a99c0d915ab',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/1e562aaab858a76986513353116e88e6.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b549ac9a6e0831464f6a6bcb4ba7e22',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/68dc420823396fd859192ee67116f3a9.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a6c2b34b74f3d676895eda2e7b7f36d',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/5506de62667ccce3d3273854fd94ce08.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3710ee8c79ec140442e7ee2247b943e2',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/20def64a0faabce5724549dc7d4daf29.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67f46622ecceacdcac448460624296fb',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/5f84145303679d3da55a67ab2a0b05f8.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4040c9094ca891b63bc407a16dc87554',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/78e9da63935adb0b27999a5e2342d204.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fac1b85d2c6d635faa33f24579dea05',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/5f9c05e3fc5a55abefee46403b1761c7.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '980d71fa5a74763f9cd1c03cf2a3cf4a',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/5a0df81cda3057ddb60008575dbc2e9a.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68e81891e2ecb17b5351685504611b9b',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/9f83203b0b0565af4628dcf0493ebb4b.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '119894ece40cb12fe1a84b063f15bc6b',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/30a31c4d92057d7e35a97f90f1bb58f0.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '520203a778fdef54f8f7547041b30534',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/9aab05b9a1c4c910f99ef179b11cbec3.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '310e8e8032d8ffb9bafd457492ce5fa8',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/e8d07d67746afa810c1bc882195e2f30.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80c7dd471ebc017a7efc43b35c3f169b',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/deb5054360a8453a0ed6e67b01edb84d.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa8087ffdc1e8360632fa16c603d6597',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/9ff463111566549b17d315c77b406a71.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6f2c28fe5790ad0a926cf3a18802b7b',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/f7fa4c9603f7e2c9b7d17044728028da.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7904bfc9af86766d458fdeaeb8ba3320',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/761666477aa56bb622874dc027e6d49b.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '10af5b2a5318267a440bfcc074ade6d2',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/0732415fcf14870783c92e00c5a20477.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41fd17707cbfea62b4902fd716e79d2e',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/8b9e6ac2f78954eeb1578285ed13c71e.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'abd4b0d6ef114e1647f400f5427ef14a',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/cfd3fc5ca50c2035d4067950d247c731.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4819e50ecb2701fc6dcca5f8dc93c461',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/ca94f7497fd2a1fccd2406a5f8b40fa6.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7766ff3d9007752dae5c0ae1f07a582',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/bcfcb4f213dad0f614a93c98805d3004.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ed6adb235a58d20a90534ce3706d0cb',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/f8e990087ae65364d8dc4b36694118d3.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'efd364c08161e6aea08429290df46b74',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/aba851825a301167174a72eca6b33251.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '783aecf3726675c930b845c5ac1f0e9f',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/93d2d0893e917605e253f7a04c0b1a76.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93b261a9f11e9ef3babeb8fe27d050ed',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/ef0b23630d2432bd9b7aba983e3e3e88.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab32315a6271d0dd282b2c2ed2f149ed',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/d432955cb8548600b0d1b2c6a2a61527.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '482b4a8e67132126b10db66ee395e5f6',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/0fb8d9aee678035e82d59bcfa3c4b3d4.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef4dcdd01ae58cfb88fca9c4e46d1672',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/4ddeda14af869eeaf2674f9ac7a2d338.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f713f9cd0515a680cd906f50840eaf41',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/4c64e46d3dab54891f9afcd10dcefc89.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42be11531faf7a6d9647aff3a6ad60a4',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/fa240e833d9230c53d5fe969a75f8056.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dd3b6829a2d9433bf5b835ee3c5388a',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/525c69ec5bef9624f81eddbbe1cd7275.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32903dad3e0c3656048798fed00d7f31',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/3649138241435a0827eb3fd8a54f6ff0.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef940bd736c0ff4bd3b54edbc5542e5f',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/674945e2b5bf79b2c724488720647138.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e408f0a4c095ad3a82bffa3f39108b8e',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/d92ea7bbf9b3bb36cf0dfbffc2d5e484.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39d2297e3394ba4e0a1ccf1f6ccc6827',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/ee75500ddefa4d5c675d18d4a449e264.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee6af5b92518640b5201f14ffb7ea67e',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/0135dc917505ae4a947c794224b2a929.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6328e4fe091d2fdba744b402010ab176',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/f22dfe4119e122ee627f2c03b629077b.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1ad43517a00fd519a93e171beed7859',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/d1c8c03e886f2db52085e16ea3801cac.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4fb764087a477913728f74a43abad7b4',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/e647ef9699fc2e7fc18c32dd42cb2269.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '708756b41dc7d2435bed5d82c1cc22a8',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/beaf05f599460841e194a06f787c1778.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16855d45750a9bc1a1e07b60f015c08e',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/09bd2d08b7915a8a0add65ee01a369ef.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a07239b747cd2e067578544285d0298',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/abefcbc61949d1e5bd9de1262790f844.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a7179a2cbea29d9de6fc856a9244be9',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/afad67468fd3ad6d6c3e25da8f4c3cb7.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf77d1fbd30cc6802bd0e9cc7f053661',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/49f909b41d02c1cdad0991c28c3198c2.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33dc34f3bfabd5aa99e9027acea6dfac',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/9e7ccf0209632d392b389a1dbddecbd3.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d9b5c4ef7828271fab24f6a2fd8d6ad',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/94b8b63ee8107712bec109964b14b222.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4d7d30e5b337947691816c141c6e379',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/249461d001ae276011bba648ac41dfc8.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eef2b6c9fda788da46aeba2915c20472',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/d440ebcf2f03dd0a4d559916e1abfd8b.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f594cb0894d1eea7acf3cf4a33cd026',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/2e3120919c11077d1d3593a19f7529ba.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cfa80f20116c05ad4e2219716109fb6',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/f54d9033ff123600872170969c60ea44.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06c1ef2ec63ca8c69ec786b31f0039fb',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/066e811ed2441883a971ee46e2cd86a3.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eec4b83d9c48f0496640706e9031e29a',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/20808e586d2ca4f562f83f639d96e017.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '593ce603cfb12bfca7a91833e1d451f7',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/c77d770a5f1f072f7f1ba49b4d0ee2e3.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '135290b2fd52bbe6d02a75b2a49e1878',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/b39a87a3a88719ca91dace0bf1b1d7b0.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01d2417881476d4f129d2f2b1b4a1195',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/919a7a5989bb9b07e0f5b0a5d27edd0e.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '532b7afe0881275d16cdde034792e967',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/b4cfdd0a0a27e9f726bce6593e82e589.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20f0f8068c955fc1b52cf4cdc072bea4',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/c8f9e38743489b2bdc1286a29ddca245.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f8498271a6ea97402fa1b1c2d6295d8a',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/8e98d26e912eddfb6bcab05442037497.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c039bac9ecce0e8e585f063dde38ca7',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/11e40bde107fd8179617eebebbcb4738.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dfd40506ae105c92c7f85871fd52eb7f',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/8a2d1dd6ca21487533dee3ebecd73382.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0918a5a69de04e7ed2fae3b7945d9ab4',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/ea606903b5c2be1ace87160ee4d7a24c.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8347f05b5472a877643a6c8907a942c',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/dff19cad50f791a97c48055db7750251.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4ec17eb5dcdc6180ebc9615521d104f',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/b53e86cb3fed1f50a2ac831bff7442af.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '936b903c6170743f61305921873c5ddd',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/1f269dfb28baaa4b03864b33bf713470.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0924229354bef3bf3816c0ce4108e786',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/24df482c7bc95ed87e557cc7f61ccabb.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f4461c4d81e3a1e43433d9f4b84341b',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/5b49ac9075cd2c14177f3b068734186e.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f4aa549ec65f8be58a373cf0df6502c',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/db8639f5a911d464062a2a4423044278.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9532b0407f92f5cf0b4ed6be8bddf706',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/fb6f3d2a37fd4a8e4d23cf4fe583df0a.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33884a5c1e5f56c2a2ceb1c29f19fb69',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/c8a5dfd1c5e67d9284a7c0a32b421ce7.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b8eda1333e10ac36c2b0bcb1485a032',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/617c100932f1c10350c7de4e9604beb9.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81b40e0fab4438805b0356ca1b351e0e',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/5f5f36a2a4a1cd66ce629e763431aefd.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a56cced0fd843093d04e4bd9128c1df9',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/c6d1c955845c9bda37ca21c4aa77da3b.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0a265938af0a506f8eaaf4a0bf8446c',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/b6d5d018e48fcc1160a494e1096d60b3.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e3c8b8876fe3e2960fed1319f0e7e4d',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/8c8c6446c5344ce41d141bb0d4fbec01.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd7f90cfa6fa9dfcd0644cacb2f9a40d',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/328cd3db518c46f1b7b360f722a1c04a.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5208c80380725d36ddd7c6c342fec8a3',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/610adc71fdf7b43bcfb76f4a58d8733f.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2a1bd6721638bd9ed50885d4057ca07e',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/7780a93674c353a2fd3badc951259f62.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba23e962ce68074f6b42f8e984ee5a50',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/018af4a9808c67db5bc79c0fa7c2b786.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d732ff7f594a79ac16d9bedab45fa98',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/d927ec3739403d90ddbd9401abb48dd3.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d66fa6fd8d79f59fe74c97c9e02d3fc',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/102d97f91cd89ba0b871c9519df9eb6b.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7192c17ab71aa08b8871f659f83ff4bb',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/bb38df6988d5f8b72419c69c7c60c0de.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '986b56548040291b337ea59bb7799acc',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/92c31d2bef54f16bbf99db9420e47fa7.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deab83015e26a6a69c7b5d13ff29cd81',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/5431c6c69fb94e322e1494cf67f96695.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4558c50c11da7260dcb615019775484a',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/8a991cb131f18ff2fe4c234ea69c5fdb.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d1f8245cb0f10cd2e00df4daf5e8ab4',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/bb771e94dc22e5427f887b18299ea445.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcfbbc4d90d77f8593c7219edb4ce95d',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/657db87cc2a8095287110cbc6376b4e8.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aa67308352de75ff3085482bcab8bd4',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/0ecd2a38e06f04a03662a2c2cb7df7ba.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85c04ed4534b9b0f267cb72f15a4f200',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/eed03a66d2f5940633fdb1c792429054.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1f2e996b9e1603f71269f1d5deb0780',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/82e2d305a061b572cc6cafbe84c1af6d.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce1ebbbe3aae8e3eafb7b1e5024d6f04',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/e8a38d18d8ec4e0464cba852d3657276.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffb958cbb07d8dc39a7e70d2e604ae26',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/74524b7e43d871d6efa2dbc9dc6944b7.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5badcaf28ef1462b9798628c9c18a47f',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/bbc20101ad7630837fc66bf5b02c1957.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b23a6322aef68cb7732586077bd93ea',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/57bcfa41cc5a0e4ef2e50c32f324702b.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b975c5ba6062397537824332333434b3',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/718893ff7f400e03c191749ec05bf1bb.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9f46c050ce0274b4cd4be5dc223d5b3a',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/65ac050d514dc80c105506a0b011ecbe.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10b0942c38c740faa33a5adbbd792ab8',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/b1b40d9a897e73f82ba5741467d26a8a.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b953848f1e534a296e51b78a6381e8f8',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/dca8147cdb8e114f05870f0ae854f7d6.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '585962a9ba71e9f8217b15a15df7874c',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/7b8e3da31ec66ba366b4b8abb65c7432.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6156ddb3aa99dd4133ccd7ddf7ff3b7',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/3cc262e721e30208b9f08189443d5cf1.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f53166a9405f26b9b96cc8aed7b27d14',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/c1564dac0148a3aebfb36359393a0ce9.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d946fda3afdba6256343a08ca04c413',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/ae4011da41dcd9ff12bb2a414075be64.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d56c7c5273f67cedaab8f03b026b468',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/fbea0afaa38de4189233fb02772ccacc.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3faaf28b0289a1e1227b47e271253dd',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/e2886045aa2f0087ce6af170d3da1733.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e33a781c7ab25e2e6148f5513b6427ca',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/b5235adafe019a8962d324d3a09873f8.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6031cf0cabcbe491c5b36f92d28aee5',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/7419dd27eeadc4d1b5fd493d9c5b2521.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '719f4e933e42001b75fa1364dd48d66b',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/0d7d610b54218e06259a87a6502715e4.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6b5f73c9b5ccd7cfda9824648e2831c',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/5aa6e21645685d59d7877cec17730390.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '492070868a735dae8f68ec0672b945aa',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/f0c42af74ace1746a1fb01452b43a628.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '827108a34e3762320e50ff1540488f6f',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/16bb7cb397cede46f621981cb6f94d69.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0986e28fbbbe0ef995bcb61575bbe8a',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/d56ccafef96f286ac9a43d429f040d42.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98218b0be7c4f57b09d5a0a07d8bdda0',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/74f2b91e20b320a792c4c92054b0d206.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08146786e7ba3b7f66cd0b95bcc56c16',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/c5bcf6f83da76de8f03f1d32132b78c6.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c42624fffd902d23076631c0defdd18e',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/f9dd912bb5f20e65345861a43edde4d7.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b31a021c44dc9bfb05a156ced83ffe5',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/accde689f1dfd0d6b567f9cda2f17d4a.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de35187cc412670e3b694e37da256f82',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/dad37eb175643e691c3ff2842958f737.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a020424f012c7c59faafe8298b989906',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/efa7e3ed5ab14fe23ed790c67be4887e.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff6385c6f79e49497dcd6d36e7cff2f6',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/4ee855af140905863bd8b9222c269e33.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cfbbe70c6310caf13182d68aa39fe210',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/2e12f0c1a66fe32904810c0f0b404310.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c3955dfe183959bd81d87b4c37f0f0bd',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/dd675d1c4d719ac985ace9d7b0d6510a.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e980baedf094d7183d8bb6b960004bfb',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/ce7a63a51a26599be785e59dfd7f820c.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f0edaf5e77bdc2778ac6a2c55f7bf8f',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/87cc6b325628b42f52e4dfdb913231d4.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '218a5d1b95175fcdbc19915bdaceb3a0',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/34a963c594428a86296dd79b7972eeb1.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a71228e3e1ed6faf8afabbb1e1010917',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/b8ddd36f322eaddb99b8e7e08a31b41d.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9195ed2b8acbd8466b361750a8a69c8',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/dcc12ca736d542bc0ab1c330c5b68166.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0157ece1bb3474165ed46eaa640b54f8',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/0a3f67f23ceae44d6f779e381c6f0efb.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bac42470e1881aab2883faa75050c56b',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/89da9a97cddb3a08ec1d2a127e97ee5d.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82d22923211ba48ba1ba1b67c1b25dd8',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/3512dd19ad067b111a609fdf5f7054fc.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '613841afe61b7d57cbf3b5a1b359b195',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/be45fcd37e046afb2287c6bc2f68ea32.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d44e69aa066323c11b39a63aeaa0cd1',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/7db6fccfddcbceaa72e5427b351b6937.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9aad31460e0f8eb0d3a0e082426d31dc',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/8cfb816c3748025d2b646f24869e4a0c.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f24a14946d97b225f806944f7160dca',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/a059b439eb417710d1afa0d28cbc17a6.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73fe10d2ba86099220b56692ba7bcebb',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/9146497a0b8565199c75b5188170b2b2.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6505ea3a98758a4126240a86b60e8789',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/2aff6cf34611c2310ef2d33f7735f74e.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5196affa3a1a8afbbd95fc696b4353e5',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/47992dcc46ee38fdbf044d72332e3ef5.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '499cd2216295276da30b2f0c7cba74cd',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/a5cc3e02fc70630a763e573d068f4fe4.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '89dc94abf10c70129ec63ca581a73547',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/3904551ab3d54f4c3d47fc16e00ecc61.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '890d217d8ae69b7b34c8fe31f69793b9',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/7b2979c77e32be658e3732b514e23837.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6930ccf11429e853e11ead7795320d0f',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/226ecf8108853ecdcab181038a4d7b71.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2a0a23055ede7f2b572302c59e2fd8e',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/b5635f525c58a6cf2154aa5b96b2986f.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7410034ad874da1aa2f4c8b6f2f44425',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/a82e5ef49f9b394cde410a1a26ed2a53.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6584d2ec27b79ae0587efcfa76c30079',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/b0d358d761336ab31fac448f176da579.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22956b923fbb2a1248474871ed344c52',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/415dd8abda7fc4f4e28d584807d254e6.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e46606277a00613229eb622e2645fbdb',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/8a98b1e37f3ed2b8a9ea86f80ba3ff17.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bd9c8ca742e46e6d6247e49f1864f5f',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/e57838f6fca13f255fa1f1c995d40c32.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82389ca832175b7ea3806592e0bd37fe',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/a27a9ef7badd0885eead8df57597283c.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '379f33f0afebedfa56abc646013baa5f',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/76f042d988a6dd718de02691af9a9ebf.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '957937828d3bda5770b79e5705176503',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/fca82befbb25633be515be26b9fc6fd3.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e48fe312355080cb3c928f9f0d0ed6e3',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/a893ab715b19646cafeaabb81fcdb90e.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bc5c601668e9ea4610232836e349385',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'modSystemSetting/9dfde1085b9419a63479c4d386ae980c.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40259d68d77d9944804db68f5af6ce9c',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/0745127e1c20a50d53b9d28bc15d330d.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27623764d7ae5075ef468e366dbb9469',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/464f335b7f01bb61a2636319a2a3f8e0.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '051c51e21151a74c042ab4be78b9cb1e',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/86ac9587a31a6e82c1e32f29da03d1b7.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'deae28d574331fbeb77699182c80166d',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/f12e93b695133d2e638c4487f78e76af.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '766bc5bd7e0be1696d122cb887d67151',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/17d81284ff01b72eb1e1904a6f8f69a4.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef3213df241c4f4822bd63cd50bb7128',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/c7e3c8ee795cf9d83357c3f26e936647.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d1030ae744e95bd66e7872406ed9abc',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/f90dd93ed303ccec2c7b3d67372be3b3.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa27494a837751563a6fe86c6001399d',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/88df23bd30fadce7a4cfdd81d8ad958f.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4bc3c3e6ed6a94e889c9244ffbc2e78',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/afae133e630d0ff536a72961435c7948.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f66d68fa0d13f70f6717b673d3ca5d3',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/fa502aa249c8e6bd9d03b6b7eeb817c8.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85804ad3793217015b45d66a651c6a26',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/39f848d0204d9900a11cb5df326e9a70.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0543cbafc20ca3eb13cc7394dae972ac',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/e5b7cda9e926326ebaa600a859172679.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1734fc52fc15056b2f96e171c4867451',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/1667e8ca8a82998990b51637dce47044.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '670b70022d428b6854631af3d40974b6',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/25e0d8ce7a397964d03494cf41ca5b66.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15e12802dabada190ea067d6088c66b9',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/83aa422d62448527482845ff795a5d6c.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '459289b9230df3a0a0daee5d24d854e1',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/d98d2319ada73b723a6fe4e90d72600f.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bb5ffa450e43e5712160efed982f00c',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/2cdaf28daa126d5e11c826b31ca463d2.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea5385583063caa69af11ad0b34b7ec1',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/9293ac2f4dd4296c8af681ee309026ef.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88899b58384bdfbca70108dea2986792',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/9d3a7f4cbc1d9de4dcf6003504ac5ba7.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a529f0381fb44e81146c53b4a17ec3e8',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/e60f5b1576fdfe628ff9c54a9de62522.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '221041a640cc6c6210fb5510793bce75',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/9103ad72b420384331d77ca186695173.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e1360b32435f72801ec03324eaaee52',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/41c629b401172e3a6159a348d2a4ba16.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '089dbb49eab18a85b2c9b34cc3b319af',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/e12212290458083c6f2c43db5da98049.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b33bfed32766228bc22328b43e7d30d4',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/bb588f969f96b71461cc9f5f86628ec7.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dabe281d8e5f4c60bcd80b40f4b6d10a',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/9c16726604150f90a08590500f6e5b0d.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac8fd23a86f104d39e1fc1883efaaf6e',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/444b2421059b675bfc26b9e23979f83f.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ffa257eeb115202605de192085d7513',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/c8da1085ca144334851ca5cc0fd0a19c.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f14b047904aafc6cd4845d9d51bbfe2',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/40029c114b4ea9d775c0d12b348358c5.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fe428bedaa3d113d787c6e92dab5b26',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/cd0457eee7f867fa1fcea971cf7e2f5b.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a72723faa6a240399fe8c490f3227b91',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/1254c271783aa54021766332ef3a73b5.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00b356397f93a9d2680c497d84f9843e',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/a67aed4374264b8da6f67c882bbfa4a6.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '935623d91c40f16af6feda53933395c4',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/d8be60cca6fe20e4614c1c69b23d153f.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7ca814fce2eb4910b5704e9fe9a63f2',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/889b00a528aa3560a3fbe706cc6b372d.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '310b07e0db3aa9c3f475702c78012f31',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/6e297599571f8d5b9498e59613db4f9c.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8959ad93b16266fa8ec6a4d88ff1be62',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/ea81890ac0cb8c9c2fff7eb58fa3c083.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '473f2c7f96a94e1a8d2f76b49be5987b',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/3e2de63220ecda5d5d9659ef903f37c2.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abcda68b55b4b16656ca7ef24b911d8e',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/43d0b786764f92579f1ee1093b334031.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '83633b5f1976ed1b4d93b9e3c9ed818a',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/3bf6065a890d1bd4dc02c7ff8a844202.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f3fe196de829294450f8bfc0f07ad1e',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/2091885413095baf340ff385cd1d857b.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60db6c7065ce5a6ed62e78ccd3eea1d5',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/842d07d067c8a1a089fc68923c37cfc8.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c47e53f47000b8152601faf0eef4486f',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/424bba2ccd9b69d4a97cb2ce4438b76e.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c54060a33fc834fc0c5e2597ddaab1a',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/37208d82fc320b2d157d0306b188748d.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10c56a0a8ee1b91851f96340f20f84a2',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/65ac30608ce71cca80fc0c294b68d8a5.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '177c3f8aa3d21fc89d9afe6539f23d81',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/2eff4c98417faf7db0b3dc468ebc8b78.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b35c47ee1f30c9aaa1c8bac0e51fce0d',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/10e348bd3510115276199fa2af2033a2.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e672f804dbb2320a6f6e685f7e978802',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/2ed53872e9a48907e09dcb55b8057397.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ff83b9d4699180e39135608d9b5fc29',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/1cf44d1ef0aecb946e2ad7b8d77b218c.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b17ef8dd5d0d98cfdea9b982604efdc3',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/d6c5c727bfc3b743e9fb4e39a1a0b5a0.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f57b1a44aa2af9bb305063f78fc70238',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/7241926d852951592a42b8c744d24aff.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aff0e6149903d10e5e0c457fc9523bb',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/a1981c5e18049ec444524ee8badad66d.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b65c2eacd408ebd53efa984498f74f83',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/1ffa4890111e5da712791efdc39976b3.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b98fb31212ae7a657aa32395d688891f',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/518ae830044c34b66563aefeaf253c18.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffbba7576dca58a0fc1a60c162828d5f',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/4b9aa41449d56ce6df2a98a28a479d08.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92c06f4ffd21d0afbe10d54c503348c5',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/a10d2adaeb1379dda12b2a80d97a3cc1.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07cef3a69f6c9452af2fb8a6e63f464d',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/78b4d022db57289eff707bbf7f95c9bd.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9493045f04e82e392c985c881a8ecd31',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/63665decb53026404d5aa44e27fa9456.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9509e1ed0846982d097c687700b02ea',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/daa23ebc5eb83e46c43d0a8ccf9092a2.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '22254e5cb1f62a812fc1b7297fcef730',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/891fda091db39b1804509a3c5a59b7b3.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7616c3cc787d2ee7271bd7ce186a7f4f',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/fc4cd103cc1b01d760fd74c32c7ce553.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3acc3f54af31aea3a78c45a110de9bae',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/ec64968f057751716b2cfecfc572eeab.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '244e3072164ce930e42412d7c177ee45',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/4938002b2c05590d0c8c41626666c27e.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80f7900ef849389f64266275bed6c8d3',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/a7e868a1e09e7cc224bee2f15a0c03a0.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77aeb98fca79af2deb2fef01c77ec813',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/a6af0cdb67095fcf7e1bed0ae8c7048c.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a822ad0b092f804d2dfb4c5934103eeb',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/75de5860ae8ca5f30e3eae986cbdd170.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8021d928efb955b599bb5dcd574881d',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/bc18a4a552d63fd97c0f466eb8f768b4.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e60431306a527ba6d62ce61925361cd',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/8e25b8ec0c9119b6294845a7e76c879f.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '12638c9c8390c1bdcd2c69edbccae26b',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/6b4c6788966b36cc108aa862d5e773d5.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c40c4f8df0ae9d84f309e4e03cdf6cad',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/d1d26c6359883139b9f13047372ae3fb.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4967ed4ca5efe4b0548f911551a5f796',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/36c74b2a18ce98692c85554b744fe06d.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9ef1bd548655e6e9c2c66d5b67c7f1d',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/b7e5f11b1c17d72cbf6f105ffe11d92a.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '468b2ac4fb5e7eaae30d151fe8cdaf0b',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/510afb0c052b988e36eec2e682d41edf.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '461d352dd26adc287626b78304209f74',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/c341dd84ab246ff442c0f58a2368a584.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fdb8ddc1c2a671351861b35b871d57e',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/508b3d5b7815e09228255ca8b48f2df8.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77e95c18233d1b8963f186591b3c7a04',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'modSystemSetting/124f3a7351c1392c1916340f7b27590c.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '226d7e0e965cecdd6cdb3600232f0c52',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/39a4fd9e2a67ee606acdf2670383d941.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '176f9200f9f81523fe7f4ad6a145cbf3',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/d7bf34081dcf620a6fdb587bb70ea1f2.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ddd2bc4ac6a1763185ba238005baa94',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/ab9a79f6637d17960b43a2831f41c787.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0689cbe0bd139dc4588353791a812101',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/359ef909fd3d50ee5d2ddcb8a1e0fded.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '274a17a41bb6582377e8a9b17463d2ac',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/32396f2b6503377d188511733a3e9c0e.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdadaa895124a27a3b9de8980352f585',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/c1ae3212be88cb0fc92581ac5c72d3bd.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff40cc3d3aa41bae0cc2831f0307d65b',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/0c6f866e8211d38773aaf155c334fced.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '699428fdf154051a6d7a1f899f829eed',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/a752d440a0a5d42ac14249dc8bd3dd3f.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c426d9f9a68c03ff07c6f630cddad455',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/e2eb4a5d9703c8f5af45932c0cf9283d.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14b62681ae2612881b94c739f5458e1c',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/b0988dca76e7a697c1925dbde471653e.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15db14ca8aff4c2ba9054649a3b4daa8',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/5d6a0ebde453763fe6348ac193499bbc.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98b987c7a27cd1ed7d43b09e834306a5',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/89bc0a3faa9d0ac1cd3fa7e92c45308b.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c9f549cb4c02c7ba17d36fc15994a38',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/18c9b9f1ce0058399f8218883f0c75a9.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9fb4f7c9205b0742d4baa4b56711dab6',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/b413187b34a8fbc14b8e3f17e5278054.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '452c05725a634dd2c8548e7383de5f80',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/69a76303e63f9da71b497c375197f26c.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7ca3ad0f77dd0ff9c720e993fd876fd',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/c79efe330c019e7e8f825b6ef0c3fbcc.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '873ed95050d862fb0f4a66c388089454',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/fda2d6400b382e25a35a5356ca6d6789.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'de4e7626be296644eeb619e3f6bdc651',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/2878a89377edd2a64d698c899048dd46.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab8fd925c296c2eb0206aab250a93d6d',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/863c87325e5af1631aff36b3f957ddf4.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce2e37c2fbffc14cdd493af7dd2560e7',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/335c83f7a39a3b4d2af0ab66830bbcc9.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e516f2fde5b4b119dad9fa9721b5857b',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'modSystemSetting/ecfab63f9049bb40216c2dd1d25fdc4d.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '48b1592c31c837be076f70d28af81202',
      'native_key' => 'resource_static_path',
      'filename' => 'modSystemSetting/b7399254fd6d483edefe075e7981eb04.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2de68b2935975ea4a19df3b2c44ccd2',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/c32db507531b2b4b5d22fc9715ecf252.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b61b682353dfe04ba8061f0a7053d044',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/3bedacd7e1b1a4a64fd31fd9d621c238.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e22044fdb096604debfab533588c208',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/8ebbd3ca3ddc737c1dd9150080b4a2b1.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5b3e24ae3c2ec05f07935103fe52be7',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/dea4ca3e86647948fc272cca0b4f63fc.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd644622df395e95f96a8ec6e5f2c4952',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/e6d507e6c1170e6567342a9256dc987c.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27c31aab24860717c2104376ea4fd41c',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/40f28417a25ff2f93aa42a7f0daa986e.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52aa81fa6c01c6be1fb24958457f692a',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/f4a61f763e2ea7bdbb39531644dcb86e.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e68a01fd0465c1eac470e073e6735843',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/0ed9e1a060db4522c3845d94821a5a85.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b5f8f8e44e78fc6cf3bccc31b811cc6',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/7d6a4bb0d51d2da6f71ae040733343ea.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '42d72d2b63f3cf19cc23e895ea8e7e54',
      'native_key' => 'upload_check_exists',
      'filename' => 'modSystemSetting/5deb3fb0b210520005c59c7164b6dd8b.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dcffc27792bb11f9a54715f999678e3',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/f83184187fe504aa4de700aa6debde70.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e6ea998c69c5d99c24c7d65255fe5aa',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/b1f76d57353d4ed4dfa4629c11b5822b.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d0ad07ca25cab5bb034a7e652602f5b',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/d5d8aeba2eb93613f40be6085ef6c2d2.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4f47b8c0b5be079fe2015392090b01f',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/3dd9589c50c27f112889b13a01cb26a7.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fb0315f78d54cc24880fb390e434f772',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/8f5bc4abd01049635d40dc59f1e9f1ce.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16624632bc996b16887359f12503a730',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/08895ddf6032d4f8d10ec4e68aecdda8.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67d0a0c997ad4021a15edf83aefac87d',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/3d14d9614c622c1622698ddc97999b81.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1b449f6e24e49f615b4966fa8ee25de',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/1f873a3a657e699b8c5d04b9dd7a1057.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a077b76fcd725ff4acbfc687ac0a10e',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/f2ddd8cc9acb26b6fb138b172d34674d.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a057cf44de3bcbaf7fb7e93978dbd94d',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/421365e17ba4300c29098411f45c206f.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9de5bda0425b827a4156e1223c232f7',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/1a3ba9e66fa65658dcbd027497a9f3d6.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4c5e9314c6f6095bc38cc3890e54ab3',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/b563bfd9ebd0571a0df97d8306da8d25.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7008e6d45ac989f6874255e3b56fcefc',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/a1cf574da4dd4cb8c661d349c797986e.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c16d40e3afb9505914e1c54c87855bae',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/16e56dc479082f213b023f38b31b08eb.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fc143176a706a4139cc166c92c437d3',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/b730ff0894b6efbd2295a013afa9e0ea.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '395028309b051c5fe305f95ddb16b4e5',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/706db5bc1a8bc2068d932042b938d4ce.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd142c7c7b8dec79df9169ae91b25b0c0',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/503db64a10243ee0e6a27358f5f37d25.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbf6304b74487e4317c6db7510f25632',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/3417eb9c71d52b959c98c218813ff16a.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '076873c80659fa62e7ab7b85a38547ac',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/e3bc0308c5a773c0d1d1205c8041399e.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f85eb7dadb8bc158ba39e7676b787a0',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/75523a26184802f87f2fee922da6a9a6.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa6d2be448d8a5db21d759bf690aaab8',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/87b9f368497439afa2846ebe50dadae4.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '994f1f281896c8485de1ef9357bf5590',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/33b65f372e04c04270490278b1a83103.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb9cfd084d5d8864a15230ca89e5845e',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/afee93064b1ddda7870e6b7cbf951bb5.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '804f8cdc7d66a97fc7cad4b56dd29460',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/3965413f21203b0e223fc134669bb5c0.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f7ca03bb2c4b7ab39897d9918e552688',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/a7aa46190a7de896c352ce738a6a0165.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '274d4d40d56833b90d2748875b22f6b7',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/5124322d4063c0c26e76e950ab913a8d.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20bcc3d47c06723e991d222fe743bf02',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/420c44d683b9f99208b22d0c076a55b7.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e79d4cec4e6e13b03bb6c74cc834cca',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/b3d912200b8f3e507218e0fdc2512b6a.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc18850344e218fc694145a79351520a',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/a8d9595933b8aefa2bc269539dbb0422.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff07ca7672b31863b3bbd67ba9085403',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/1b4409cf79bac778c2471d6f94cff408.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0832aa147bcf6ea5b627f719f176b2fc',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/dfcda8f7ada432d8a7dd76cb33851387.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '342fcb9e60464c3165f289cdf32c27b6',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/d904632efba11edc7e7f59cef2113a9a.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '576f56c4c4af281bb7de5d3fb73741c0',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'modSystemSetting/bfb70ec33793ed37d3215d24759edaba.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'fdc328004bce2d88eec3ffc1cd0334a9',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/22a1f70b9d704f078b49c6736eccf48c.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'f2caee61a0e9943a855b32341426517f',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/28a2e6af60bdc4362dad5d26be374112.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '960ce0d128e1f61bc0c20fbce0a50cd8',
      'native_key' => 1,
      'filename' => 'modUserGroup/40c3792968703bde5e43c1fd24cafb76.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => 'c246dcc0cfff5b499877ddb4f732e4b0',
      'native_key' => 1,
      'filename' => 'modDashboard/ae71d4e9d399bd44b867b1650a4e365d.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => 'd382989609f34b0ecb5490f795f6548d',
      'native_key' => 1,
      'filename' => 'modMediaSource/d14e1575ee6e571bad8e60069c0c9ede.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '6ddad1038b0a941d57da025c84841be3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/e9146bd572ee9497c07bca5a8168b6d4.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ec74726adb1f59442651ff674b9dfb57',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/387a30910527cbd6119d1aca956a45ee.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '061e31f6b51f79dbde399fb3d6678081',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/3dd5b21492e4210db2fcee482ea991c3.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '40d82b3b5c39ea0ea06795aedfe7ad4b',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/6f8a23232dd556106d11dfca28ec5474.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '49f7c968db8ecd58bc4e901d9c3891f8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/9f59bf29cf37267122869c5d75ddad41.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '751014917b1eaf06e8806e5b6f8471c9',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/e0df0ad6da3f9ac7730aab8c07b6a930.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '3297d33b677b5627fbbbef9a93dad293',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/d5c4c9e9cd852336529f7d64cf7fc876.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '5c491d60190b4863be7539fe5731ea70',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/0957e394ad8501220217c5e363c86d55.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7e549a2dff1d71e8a677e54ee05bf91b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c131b4673c215f758e321119798ff0ff.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '65ad22df8ba77094ec0a95f687155dea',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5a374cfddd8fbdffc50cf6ff704d5ab4.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'bb9585cc3c4e4a848a01252223e0b71e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/c7814f7b8e6dcd9c4935bc40aef91f5e.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'a097f12deeb3d140a5717a61ca030332',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4d438c1e007667dda736534570b44fde.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'affbd5349f6ca803f001fd3026a36f0c',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6be573437fe03977dc52f25f7379e894.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '8a21a7feb079e31110c8e3ba56192ef1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/2600bdd45cf9fbc769cc744f8dc01b0f.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3081a9a9cfd20d74d0ad87e78895e539',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8e081052bca1158ef55850d141df960c.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '369e8a10208a056f6e8ddd8f44a031d4',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/841cd2ac2cbccf45f62c4f8c907c77bf.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '16c952f28bb2df99264de1e606a0f10e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5f56dd56cdce786a15be83e2a6e4ec95.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '941490dcfaa46e240ba73c86f2893cbe',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3ab87e2344c9aa19e8bb2bfc550ce20b.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '883aa9be7230eb2549f46cb80601ed09',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/7c6e8c25bbdcc661c0d807ea339d6aba.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '09b8c62426525cceed1bffa54ef06131',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/85aac3a675df56c23fdf826fb80fc6bc.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1e82c63be895365aad5b8d1dfdf96bb5',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/b5e31d414c548f603b5db5d53be6b5c4.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'adbc64b927548cd0c6934a81fde22186',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/0d2c8542018540b915595cd2ff9b672a.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '79a2d95170408a8b7bd147cb32ae0a92',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/baab7fb487edadb8330b0fa99653456f.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c8160456ba2cd57762347374a74931a2',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/2c25d3901d4d4cd9efb780362065f8bb.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ccc24d1db14feb0ff8b150006bd622c8',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/eecda4a825982620d4004693cdce8d97.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '91d8eed9f3d73730cdf74739cec52eeb',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/6c7f5b18c364aa4fd94ea004fc085f21.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd381a0e7c1438fabd653d5683dfad987',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/a42c1c754e6ad3d48948198f67b6d375.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '51e25a930a42cc2161936a3f40b7dacc',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/ee8a968bdfa6e081abf50627a357705a.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '550fdf14492e2f51b6fa588d6cd543d3',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/f998fd8a7b6ba8b4510345d5874911d2.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '17c101d9fef0fab1832fd80dd73a3ef4',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/31b443686ddb12b4cb67d00e02737e72.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '84f4ce62f217f6e96b95919db274af6f',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/0faf0dc7a9336e435275e327cfc0576f.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '2bddbe5d27aeadd323c20eb69072e40b',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/d64a6afc6c03f53ad38d5855ceea3767.vehicle',
    ),
    495 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'b5978adcca9538ed9eee583111143b9a',
      'native_key' => 'web',
      'filename' => 'modContext/c269eb236df12615543d7852f5162415.vehicle',
    ),
    496 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'b0f35abc3dfba22036804cd707d38071',
      'native_key' => 'mgr',
      'filename' => 'modContext/aeb88f55cae6f7be359c6a4d5e09cf3a.vehicle',
    ),
    497 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '2fda1433d8581860841d7eb68ec7c636',
      'native_key' => '2fda1433d8581860841d7eb68ec7c636',
      'filename' => 'xPDOFileVehicle/d4fc00035921fb628f3041d23cbf2c4d.vehicle',
    ),
    498 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '689584ce2ed8e73d389a3b6e0ec9e32a',
      'native_key' => '689584ce2ed8e73d389a3b6e0ec9e32a',
      'filename' => 'xPDOFileVehicle/56187745aa24980372e9e49a0286584e.vehicle',
    ),
    499 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd5e89b24a5d8cf07f17437761ff55aa3',
      'native_key' => 'd5e89b24a5d8cf07f17437761ff55aa3',
      'filename' => 'xPDOFileVehicle/6bd8c14e4ceb5711b9ee9c255edb84b7.vehicle',
    ),
    500 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'd2b6b1f843a0ff1c2179ed2cd9ecefdb',
      'native_key' => 'd2b6b1f843a0ff1c2179ed2cd9ecefdb',
      'filename' => 'xPDOFileVehicle/2597de8e1089dfce16a3184b0aa4c649.vehicle',
    ),
  ),
);